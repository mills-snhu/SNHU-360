package com.zybook.inventory;

public class InventoryData {


}